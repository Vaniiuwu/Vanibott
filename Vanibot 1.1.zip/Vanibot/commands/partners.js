module.exports = {
    name: 'partners',
    description: "Sends invites to our partners!",
    execute(message, args){
        message.channel.send('https://discord.gg/KCx6c5qrDM');
    }
}