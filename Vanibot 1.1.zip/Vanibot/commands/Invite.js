module.exports = {
    name: 'Invite',
    description: "Sends invites to our server!",
    execute(message, args){
        message.channel.send('https://www.discord.gg/HornyEmpire (Where my mom lives)');
    }
}
